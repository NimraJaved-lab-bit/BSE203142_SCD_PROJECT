
package student.information.system;

public class Emp {
    public static int empId;
   
   
    
}
