
package student.information.system;

public class StudentInformationSystem {
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
